﻿namespace Hik.Quartz
{
    internal static class Consts
    {
        public const string DisplayDateTimeFormat = "{0:yyyy'-'MM'-'dd' 'HH':'mm':'ss}";

        public const string DisplayTimeFormat = "{0:HH':'mm':'ss}";
    }
}
