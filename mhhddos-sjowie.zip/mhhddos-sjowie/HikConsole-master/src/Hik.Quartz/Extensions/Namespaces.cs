﻿namespace Hik.Quartz.Extensions
{
    internal class Namespaces
    {
        public const string JobSchedulingData = "http://quartznet.sourceforge.net/JobSchedulingData";
    }
}
