﻿namespace Hik.Quartz.Contracts.Options
{
    public class JobStore
    {
        public string Type { get; set; }
    }
}