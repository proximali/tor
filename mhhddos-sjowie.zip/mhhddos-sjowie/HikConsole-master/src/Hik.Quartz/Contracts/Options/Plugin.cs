﻿namespace Hik.Quartz.Contracts.Options
{
    public class Plugin
    {
        public JobInitializer JobInitializer { get; set; }
    }
}