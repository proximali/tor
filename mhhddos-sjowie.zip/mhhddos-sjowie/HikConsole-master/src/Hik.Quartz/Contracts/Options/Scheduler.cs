﻿namespace Hik.Quartz.Contracts.Options
{
    public class Scheduler
    {
        public string InstanceName { get; set; }
    }
}