﻿namespace Hik.Quartz.Contracts.Options
{
    public class JobInitializer
    {
        public string Type { get; set; }
        public string FileNames { get; set; }
    }
}