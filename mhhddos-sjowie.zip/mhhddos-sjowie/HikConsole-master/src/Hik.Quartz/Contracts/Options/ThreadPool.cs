﻿namespace Hik.Quartz.Contracts.Options
{
    public class ThreadPool
    {
        public string Type { get; set; }

        public int ThreadCount { get; set; }
    }
}