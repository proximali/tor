﻿using Hik.Quartz.Contracts;
using Hik.Quartz.Contracts.Options;
using Hik.Quartz.Contracts.Xml;
using Hik.Quartz.Extensions;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Quartz;
using Quartz.Impl;
using Quartz.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace Hik.Quartz
{
    public class QuartzStartup
    {
        private readonly IConfiguration configuration;
        private IScheduler scheduler;
        public QuartzStartup(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        public void Start()
        {
            if (scheduler != null)
            {
                throw new InvalidOperationException("Already started.");
            }


            LogProvider.SetCurrentLogProvider(new ConsoleLogProvider());

            var options = new QuartzOption(configuration);

            InitializeJobs(options.Plugin.JobInitializer.FileNames);

            var schedulerFactory = new StdSchedulerFactory(options.ToProperties);
            scheduler = schedulerFactory.GetScheduler().GetAwaiter().GetResult();
            scheduler.Start().Wait();
        }

        public static void InitializeJobs(string xmlFilePath)
        {
            string jsonPath = xmlFilePath + ".json";
            //jsonPath = "C:\\quartz_jobs.json";
            var dict = JsonConvert.DeserializeObject<Dictionary<string, List<CronDto>>>(File.ReadAllText(jsonPath));
            GenerateQuartzXml(xmlFilePath, dict);
        }

        public static void InitializeJobs(string xmlFilePath, Dictionary<string, List<CronDto>> jobTypes)
        {
            GenerateQuartzXml(xmlFilePath, jobTypes);
        }

        private static void GenerateQuartzXml(string xmlFilePath, Dictionary<string, List<CronDto>> jobTypes)
        {
            var serializer = new XmlSerializer(typeof(JobSchedulingData));
            var data = new JobSchedulingData();
            foreach (var jobType in jobTypes)
            {
                foreach (var cronTrigger in jobType.Value)
                {
                    cronTrigger.ClassName = jobType.Key;
                    data.Schedule.Trigger.Add(new Trigger { Cron = cronTrigger.ToCron() });
                }
            }

            using (StringWriter writer = new StringWriter())
            {
                serializer.Serialize(writer, data);
                File.WriteAllText(xmlFilePath, writer.ToString());
            }
        }

        public void Stop()
        {
            if (scheduler == null)
            {
                return;
            }

            if (scheduler.Shutdown(true).Wait(30000))
            {
                scheduler = null;
            }
            else
            {
                // jobs didn't exit in timely fashion - log a warning...
            }
        }
    }
}
