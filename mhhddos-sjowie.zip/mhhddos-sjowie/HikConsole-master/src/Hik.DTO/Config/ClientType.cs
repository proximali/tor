﻿namespace Hik.DTO.Config
{
    public enum ClientType
    {
        HikVisionVideo,
        HikVisionPhoto,
        Yi,
        Yi720p,
        FTP,
    }
}
