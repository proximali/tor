﻿namespace Hik.DTO.Config
{
    public class MigrationConfig : BaseConfig
    {
        public string TriggerKey { get; set; }

        public bool ReadVideoDuration { get; set; }
    }
}
