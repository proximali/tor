﻿namespace Hik.Client.Abstraction
{
    public interface IArchiveService : IRecurrentJob
    {
    }
}
