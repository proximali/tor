﻿namespace Hik.Client.Abstraction
{
    public interface IDetectPeopleService : IRecurrentJob
    {
    }
}
