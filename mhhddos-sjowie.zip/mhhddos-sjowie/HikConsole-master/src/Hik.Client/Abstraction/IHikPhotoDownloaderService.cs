﻿namespace Hik.Client.Abstraction
{
    public interface IHikPhotoDownloaderService : IRecurrentJob
    {
    }
}
