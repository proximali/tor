//2022.8.9.7
using System.Reflection;

[assembly: AssemblyCompany("Hik.Web")]
[assembly: AssemblyProduct("Hik.Web")]
[assembly:   AssemblyTitle("Hik.Web")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("2022.8.9.7")]
[assembly:     AssemblyVersion("2022.8.9.7")]
