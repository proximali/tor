﻿using MediatR;

namespace Hik.Web.Commands.Cron
{
    public class RestartSchedulerCommand : IRequest
    {
    }
}
