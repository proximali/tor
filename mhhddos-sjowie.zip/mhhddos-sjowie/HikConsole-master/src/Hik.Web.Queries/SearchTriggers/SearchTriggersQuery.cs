﻿using MediatR;

namespace Hik.Web.Queries.Search
{
    public class SearchTriggersQuery : IRequest<IHandlerResult>
    {
    }
}
