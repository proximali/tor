﻿using MediatR;

namespace Hik.Web.Queries.JobTriggers
{
    public class JobTriggersQuery : IRequest<IHandlerResult>
    {
    }
}
