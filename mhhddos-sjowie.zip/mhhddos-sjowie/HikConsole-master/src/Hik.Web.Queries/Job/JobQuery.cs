﻿namespace Hik.Web.Queries.Job
{
    public class JobQuery : RequestBase
    {
        public int JobTriggerId { get; set; }
    }
}
