﻿using MediatR;

namespace Hik.Web.Queries.QuartzTriggers
{
    public class QuartzTriggersQuery : IRequest<IHandlerResult>
    {
    }
}
