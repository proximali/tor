﻿namespace Hik.Web.Queries.DashboardDetails
{
    public class DashboardDetailsQuery : RequestBase
    {
        public int JobTriggerId { get; set; }
    }
}
