﻿namespace Hik.Web.Queries
{
    public interface IHandlerResult
    {
    }
}
