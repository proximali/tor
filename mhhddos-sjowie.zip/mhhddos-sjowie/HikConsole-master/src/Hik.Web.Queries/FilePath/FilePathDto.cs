﻿namespace Hik.Web.Queries.FilePath
{
    public class FilePathDto : IHandlerResult
    {
        public string Path { get; set; }
        public int Id { get; set; }
    }
}
