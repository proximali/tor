﻿namespace Hik.Web.Queries.JobDetails
{
    public class JobDetailsQuery : RequestBase
    {
        public int JobId { get; set; }
    }
}
